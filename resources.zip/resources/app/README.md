# Construir arquivo de importação
Sistema para construir arquivo para importação no GM Rotina 402 e 1118

-- Aplicativo desktop construído com Electron para facilitar a rotina de trabalho ao fazer importações de programações de preços, o palicativo gera um arquivo baseado na quantidade de lojas e códigos a serem importados, pode ser gerado um arquivo no modelo para a rotina 402 ou 1118.  
